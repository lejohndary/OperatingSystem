#include "pintos_thread.h"

struct station {
	// FILL ME IN
};

void
station_init(struct station *station)
{
	// FILL ME IN
}

void
station_load_train(struct station *station, int count)
{
	// FILL ME IN
}

void
station_wait_for_train(struct station *station)
{
	// FILL ME IN
}

void
station_on_board(struct station *station)
{
	// FILL ME IN
}
