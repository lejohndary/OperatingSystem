#include "pintos_thread.h"

// Forward declaration. This function is implemented in reaction-runner.c,
// but you needn't care what it does. Just be sure it's called when
// appropriate within reaction_o()/reaction_h().
void make_water();

struct reaction {
	// FILL ME IN
};

void
reaction_init(struct reaction *reaction)
{
	// FILL ME IN
}

void
reaction_h(struct reaction *reaction)
{
	// FILL ME IN
}

void
reaction_o(struct reaction *reaction)
{
	// FILL ME IN
}
